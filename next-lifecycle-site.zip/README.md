# NEXT Industries Manufacturing Lifecycle Flow

Static, self-contained interactive page (no build step, no dependencies beyond Google Fonts).

## Structure

```
next-lifecycle/
  index.html        Page markup
  css/styles.css    All styling
  js/data.js        Lifecycle, automation, and Crawl/Walk/Run data
  js/main.js        Render logic and interactions
  .nojekyll         Tells GitHub Pages to serve files as-is
```

`data.js` must load before `main.js` (already ordered in index.html).

## Hosting on GitHub Pages with a subdomain

1. Push these files to the repository root (so `index.html` sits at the top level).
2. In the repo, go to Settings, then Pages, and set the source to the branch and root folder.
3. For a custom subdomain, add a `CNAME` file at the repo root containing your subdomain, for example:
   ```
   lifecycle.next.industries
   ```
4. At your DNS provider, add a CNAME record pointing that subdomain to `<your-github-username>.github.io`.
5. Wait for DNS to propagate, then enable Enforce HTTPS in the Pages settings.

## Local preview

```
python3 -m http.server 8000
```
Then open http://localhost:8000

CONFIDENTIAL. NEXT Industries internal use only.
